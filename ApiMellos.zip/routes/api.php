<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use App\Http\Controllers\AuthController;
use App\Http\Controllers\MedicoController;
use App\Http\Controllers\MuralController;
use App\Http\Controllers\UserController;

Route::get('/ping', function(){
    return ['pong'=>true];
});

Route::get('/401', [AuthController::class, 'unauthorized'])->name('login');

Route::post('/auth/login', [AuthController::class, 'login']);
Route::post('/auth/register', [AuthController::class, 'register']);

Route::middleware('auth:api')->group(function(){
    Route::post('/auth/validate', [AuthController::class, 'validateToken']);
    Route::post('/auth/logout', [AuthController::class, 'logout']);

    // Mural de Avisos
    Route::get('/mural', [MuralController::class, 'getAll']);

    // Medicos
    Route::get('/medicos', [MedicoController::class, 'getAll']);
    Route::get('/medico/{id}', [MedicoController::class, 'getId']);
    Route::post('/medico', [MedicoController::class, 'insert']);
    Route::put('/medico/{id}', [MedicoController::class, 'update']);
    
    // Medicos do dia

    Route::get('/agendamento', [MedicoController::class, 'getAgendamento']);
    Route::get('/getdisableddates', [MedicoController::class, 'getDisabledDates']);

});